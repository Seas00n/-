clear all;clc;close all;
%% 此脚本用途
% 1.利用大腿角度数据计算相位值
% 2.得到相位值到标准腿长的映射
% 3.得到相位值到标准力的映射
%% 使用步骤
% 1.导入数据,计算虚拟腿长及其方向，计算地面反力在腿长方向上的投影，
% 并且对数据进行滤波使其连续
load data.mat
thigh_angle = data;
figure("Name",'Thigh angle in stair ascent');
plot(1:size(thigh_angle,1),thigh_angle,'LineWidth',5);
xlim([0,100])
load data2.mat
cop_to_com = cop-com;%mm
cop_to_com_mag = zeros(size(cop_to_com,1),1);
for i=1:size(cop_to_com,1)
    cop_to_com_mag(i) = sqrt(cop_to_com(i,:)*cop_to_com(i,:)');
end
detail_adjustment;
cop_to_com_mag(1:10)=mag_adjustment;
cop_to_com_mag(92:101)=mag_adjustment2;
cop_to_com_unit = zeros(size(cop_to_com_mag,1),3);
for i=1:size(cop_to_com_unit,1)
    cop_to_com_unit(i,:) = cop_to_com(i,:)/cop_to_com_mag(i);
end
force_cop_to_com=zeros(size(force,1),1);
for i=1:size(force,1)
    force_cop_to_com(i)=-force(i,:)*cop_to_com_unit(i,:)';
end
force_cop_to_com(1:25) = (-547.65/(24^2))*((1:25)-25)'.^2+547.65;
force_cop_to_com(79:101)=(-574.45/(22^2))*((79:101)-79)'.^2+574.45;
figure("Name",'CoM to toe in stair ascent');
plot(1:size(cop_to_com_mag,1),cop_to_com_mag,'Linewidth',2);
xlabel('t')
xlim([0,100])
figure("Name",'Force in stair ascent');
plot(1:size(cop_to_com_mag,1),force_cop_to_com,'Linewidth',2);
xlabel('t')
xlim([0,100])
figure("Name",'Show in 3D')
position_com = zeros(2,100);
for i=1:100
    real=cop_to_com(i,:);
    scatter3(-real(1),-real(2),-real(3),'blue','filled');
    hold on
    scatter3(0,...
        -cop_to_com_mag(i)*cop_to_com_unit(i,2),...
        -cop_to_com_mag(i)*cop_to_com_unit(i,3),'red')
    position_com(:,i) = [-cop_to_com_mag(i)*cop_to_com_unit(i,2);-cop_to_com_mag(i)*cop_to_com_unit(i,3)];
    line([0,-cop_to_com_mag(i)*cop_to_com_unit(i,1)],...
        [0,-cop_to_com_mag(i)*cop_to_com_unit(i,2)],...
        [0,-cop_to_com_mag(i)*cop_to_com_unit(i,3)],'color','cyan');
    line([0,-force_cop_to_com(i)*cop_to_com_unit(i,1)],...
        [0,-force_cop_to_com(i)*cop_to_com_unit(i,2)],...
        [0,-force_cop_to_com(i)*cop_to_com_unit(i,3)],'color','green','Marker','^')
    xlim([-500,500])
    ylim([-500,500])
    zlim([0,1000])
%     pause(0.1)
%     drawnow limitrate
end

save('Webots_Simulation\leg_simulation_up_stair\position_com.mat',"position_com");
%% 2.通过大腿角度计算相位值
thigh_angle_mean = mean(thigh_angle);
thigh_angle = thigh_angle-thigh_angle_mean;
thigh_angle = [thigh_angle;thigh_angle(1)];
thigh_angle_int = zeros(size(thigh_angle,1),1);
sum = 0;
for i=1:size(thigh_angle_int,1)
    sum = sum+thigh_angle(i);
    thigh_angle_int(i) = sum; 
end
q_int_max = max(thigh_angle_int);
q_int_min = min(thigh_angle_int);
q_max = max(thigh_angle);
q_min = min(thigh_angle);
mean_x = 0.5*(q_max+q_min);
mean_y = 0.5*(q_int_max+q_int_min);
x_y_ratio = (q_max-q_min)/(q_int_max-q_int_min);
figure
plot(thigh_angle,thigh_angle_int,'LineWidth',10)
phase=zeros(size(thigh_angle_int,1),1);
for i=2:size(phase,1)
    phase(i)=100*(atan2((thigh_angle_int(i)-mean_y)*x_y_ratio,thigh_angle(i))-atan2((thigh_angle_int(1)-mean_y)*x_y_ratio,thigh_angle(1)))/2/pi;
    val_list = [phase(i)-100,phase(i),phase(i)+100];
    if i==49
        a=1;
    end
    [~,min_index] = min(abs(val_list-phase(i-1)));
    phase(i) = val_list(min_index);
end
for i=1:size(phase,1)
    if phase(i)>100
        phase(i) = phase(i)-100;
    elseif phase(i)<0
        phase(i)=phase(i)+100;
    end
end
plot(1:size(phase,1),phase,'linewidth',2)
xlim([0,100])
grid on
%% Part 3: 腿长和沿腿力标准化，并且绘制相位和腿长，沿腿力，刚度的曲线
figure(2)
cop_to_com_mag_filt = cop_to_com_mag/950;
plot(0:100,cop_to_com_mag_filt,'LineWidth',2);
xlabel('Phase','FontSize',15)
ylabel('Normalized Length','Fontsize',15)
xlim([0,100])
grid on
figure(3)
force_cop_to_com_filt = force_cop_to_com/54/9.8;
plot(0:100,force_cop_to_com_filt,'Linewidth',2);
xlabel('Phase');
ylabel('Normalized Force');
xlim([0,100])
grid on
figure(6)
title('Stiffness')
k=force_cop_to_com_filt./cop_to_com_mag_filt;
plot(0:100,k,'Linewidth',2);
figure(7)
plot3(cop_to_com_mag_filt,force_cop_to_com_filt,0:100,'Linewidth',5);
hold on
%% Part 4: 分段拟合刚度曲线
threshold_list = [0,3,24,55,77,100];
popt_list = zeros(size(threshold_list,2)-1,2);
for i=1:size(threshold_list,2)-1
    z = threshold_list(i):threshold_list(i+1);
    x = cop_to_com_mag_filt(z+1);
    y = force_cop_to_com_filt(z+1);
    popt_list(i,:) = polyfit(x,y,1);
    k = popt_list(i,1);
    xx =[min(x)-0.1/sqrt(k*k+1),max(x)+0.1/sqrt(k*k+1)];
    y_hat = polyval(popt_list(i,:),xx);
    plot3(xx,y_hat,100*ones(size(xx,2),1),'linewidth',2);
    xlim([0.9,1.1])
    ylim([-0.2,1.2])
end
xlabel('Normalized Force','FontSize',15)
ylabel('Normalized Leg Length','Fontsize',15)
zlabel('Phase','FontSize',15)