function [num_gait,L_data_idx,R_data_idx]=stair_gait_division(force_file,trc_file)
    % 需要预先进行数据对齐
    force = force_file.ForceData;
    plates = force_file.Plates;
    figure('Name','绘制3D落足点和步态分割姿态')
    force_x = force(:,4,:);
    force_x = reshape(force_x,size(force_x,1),2);
    force_y = force(:,5,:);
    force_y = reshape(force_y,size(force_y,1),2);
    force_z = force(:,6,:);
    force_z = reshape(force_z,size(force_z,1),2);
    idx_1 = force_x(:,1)~=0;
    scatter3(force_x(idx_1,1),force_y(idx_1,1),force_z(idx_1,1));
    idx_2 = force_x(:,2)~=0;
    hold on
    scatter3(force_x(idx_2,2),force_y(idx_2,2),force_z(idx_2,2));
    plot_stairs(force_file,0.4,0.45);
    % 分割步态
    heel_strike_idx = [0;0];
    for i=2:size(plates,2)-1
        if plates(1,i)~=0 && plates(2,i)~=0
            if (plates(1,i-1)~=0 && plates(2,i-1)==0)
                if i-heel_strike_idx(1,end)>30
                    % 2表示该步的数据来自第2行
                    heel_strike_idx = [heel_strike_idx,[i;2]];
                end
            elseif (plates(1,i-1)==0 && plates(2,i-1)~=0)
                if i-heel_strike_idx(1,end)>30
                    % 1表示该步的数据来自第1行
                    heel_strike_idx = [heel_strike_idx,[i;1]];
                end
            end 
        end
    end
    % 显然第一支迈出的腿的序号为2
    heel_strike_idx = heel_strike_idx(:,2:end);
    num_gait = size(heel_strike_idx,2)-1;
    L_data_idx = [0;0;0]; % start end rowth
    R_data_idx = [0;0;0];
    if force_x(heel_strike_idx(1,1),heel_strike_idx(2,1))>force_x(heel_strike_idx(2,1),heel_strike_idx(2,2))
        % 第一支迈出的腿是左脚
        heel_strike_idx = [heel_strike_idx,[0;0]];
        for i=1:size(heel_strike_idx,2)-1
            % 左右闭构成步态
            if heel_strike_idx(2,i)==2
                L_data_idx = [L_data_idx,[heel_strike_idx(1,i);0;2]];
                j=heel_strike_idx(1,i);
                while 1
                    if(plates(2,j)==0)
                        if(j>heel_strike_idx(1,i)+30)
                            break;
                        end
                    end
                    j = j+1;
                    if(j>=size(plates,2))
                        break;
                    end
                end
                L_data_idx(2,end)=j-1;
            elseif heel_strike_idx(2,i)==1 && heel_strike_idx(2,i+1)==2
                R_data_idx = [R_data_idx,[heel_strike_idx(1,i);0;1]];
                j=heel_strike_idx(1,i);
                while 1
                    if(plates(1,j)==0)
                        if(j>heel_strike_idx(1,i)+30)
                            break;
                        end
                    end
                    j = j+1;
                    if(j>=size(plates,2))
                        break;
                    end
                end
                R_data_idx(2,end)=j-1;
            end
        end
        L_data_idx = L_data_idx(:,2:end);
        R_data_idx = R_data_idx(:,2:end);
    else
        % 第一支迈出的腿是右脚
        heel_strike_idx = [heel_strike_idx,[0;0]];
        for i=1:size(heel_strike_idx,2)-1
            if heel_strike_idx(2,i)==2 && heel_strike_idx(2,i+1)==1
                R_data_idx = [R_data_idx,[heel_strike_idx(1,i);0;2]];
                j=heel_strike_idx(1,i);
                while 1
                    if(plates(2,j)==0)
                        if(j>heel_strike_idx(1,i)+30)
                            break;
                        end
                    end
                    j = j+1;
                    if(j>=size(plates,2))
                        break;
                    end
                end
                R_data_idx(2,end)=j-1;
            elseif heel_strike_idx(2,i)==1&&heel_strike_idx(2,i+1)==2
                L_data_idx = [L_data_idx,[heel_strike_idx(1,i);0;1]];
                j=heel_strike_idx(1,i);
                while 1
                    if(plates(1,j)==0)
                        if(j>heel_strike_idx(1,i)+30)
                            break;
                        end
                    end
                    j = j+1;
                    if(j>=size(plates,2))
                        break;
                    end
                end
                R_data_idx(2,end)=j-1;
            end
        end
        L_data_idx = L_data_idx(:,2:end);
        R_data_idx = R_data_idx(:,2:end);
    end
    heel_strike_idx = heel_strike_idx(:,1:end-1);
    for i=1:size(heel_strike_idx,2)
        plot_Body(trc_file,heel_strike_idx(1,i));
    end
end