function [force_file_new,trc_file_new]=force_cap_alignment(trc,force,rate)
    x = 1:force.NumberFrames;
    xx = downsample(x,rate);
    force_new = zeros(size(xx,2),7,2);
    plates_new = zeros(2,size(xx,2));
    for i=1:2
        plates_new(i,:) = downsample(force.Plates(i,:),rate);
        for j=1:7
            force_new(:,j,i) = downsample(force.ForceData(:,j,i),rate);
        end
    end
    position_new= zeros(size(xx,2),3,trc.NumberMarkers);
    x = 1:trc.NumberFrames;
    xx = linspace(1,trc.NumberFrames,size(xx,2));
    for i=1:3
        for j=1:trc.NumberMarkers
            position_new(:,i,j) = interp1(x,trc.Position(:,i,j),xx);
        end
    end
    time_new = interp1(x,trc.Time,xx);
    
    trc_file_new.File = trc.File;
    trc_file_new.DataRate = 1/(time_new(2)-time_new(1));
    trc_file_new.CameraRate = trc_file_new.DataRate;
    trc_file_new.NumberFrames = size(time_new,2);
    trc_file_new.NumberMarkers = trc.NumberMarkers;
    trc_file_new.MarkerNames = trc.MarkerNames;
    trc_file_new.Position = position_new;
    trc_file_new.Time = time_new';
    force_file_new.File = force.File;
    force_file_new.DataRate = trc_file_new.DataRate;
    force_file_new.NumberPlates = force.NumberPlates;
    force_file_new.NumberFrames = size(force_new,1);
    force_file_new.ForceData = force_new;
    force_file_new.Plates = plates_new;
    force_file_new.PlatesPosition = force.PlatesPosition;
end