function T = cal_frame(trc,name,idx,Tn)
    narg = nargin;
    Ttrans = eye(4);
    if narg==2
        mean_pos = mean(trc.Position,1);
        mean_pos = reshape(mean_pos,[3,trc.NumberMarkers]);
    elseif narg>=3
        mean_pos = trc.Position(idx,:,:);
        mean_pos = reshape(mean_pos,[3,trc.NumberMarkers]);
        if narg==4
        % 调整解剖坐标系定义方向
        Ttrans = [Tn,[0;0;0];0,0,0,1];
        end
    end
    switch(name)
        case 'Pelvis'
            T = pelvisframe(mean_pos)*Ttrans;
        case 'Thigh'
            T = thighframe(mean_pos)*Ttrans;
        case 'Shank'
            T = shankframe(mean_pos)*Ttrans;
        case 'Foot'
            T = footframe(mean_pos)*Ttrans;
    end
end
function T = pelvisframe(pos)
    rasis = pos(:,1);
    lasis = pos(:,2);
    vsacral = pos(:,3);
    center = (rasis+lasis)/2;
    x = rasis-lasis;
    x = x/sqrt(sum(x.*x));
    z = cross((rasis-vsacral),(lasis-vsacral));
    z = z/sqrt(sum(z.*z));
    y = cross(z,x);
    R = [x y z];
    T = [R center;0 0 0 1];
end
function T = thighframe(pos)
    % Rthigh
    d = norm(pos(:,1)-pos(:,2));
    T = pelvisframe(pos);
    p = [0.3*d;-0.19*d;-0.36*d;1];
    hip = T*p;
    hip = hip(1:3);
    %scatter3(hip(1),hip(2),hip(3),'cyan','filled','LineWidth',5);
    rknee = pos(:,5);
    rkneem = pos(:,16);
    knee = (rknee+rkneem)/2;
    %scatter3(knee(1),knee(2),knee(3),'cyan','filled','LineWidth',5);
    z = hip-knee;
    z= z/norm(z);
    y = cross((rknee-hip),(rkneem-hip));
    y = y/norm(y);
    x = cross(y,z);    
    T1 = [x,y,z,knee;0,0,0,1];
    % LThigh
    p = [-0.3*d;-0.19*d;-0.36*d;1];
    hip = T*p;
    hip = hip(1:3);
    %scatter3(hip(1),hip(2),hip(3),'cyan','filled','LineWidth',5);
    lknee = pos(:,11);
    lkneem = pos(:,18);
    knee = (lknee+lkneem)/2;
    %scatter3(knee(1),knee(2),knee(3),'cyan','filled','LineWidth',5);
    z = hip-knee;
    z= z/norm(z);
    y = -cross((lknee-hip),(lkneem-hip));
    y = y/norm(y);
    x = -cross(y,z);    
    T2 = [x,y,z,knee;0,0,0,1];
    T = [T1;T2];
end
function T = shankframe(pos)
    % Rshank
    rknee = pos(:,5);
    rkneem = pos(:,16);
    knee = (rkneem+rknee)/2;
    rankle = pos(:,7);
    ranklem = pos(:,17);
    ankle = (rankle+ranklem)/2;
    %scatter3(ankle(1),ankle(2),ankle(3),'cyan','filled','LineWidth',5);
    z = knee-ankle;
    z = z/norm(z);
    y = cross((rankle-knee),(ranklem-knee));
    y = y/norm(y);
    x = cross(y,z);
    T1 = [x,y,z,ankle;0,0,0,1];
    % Lshank
    lknee = pos(:,11);
    lkneem = pos(:,18);
    knee = (lknee+lkneem)/2;
    lankle = pos(:,13);
    lanklem = pos(:,19);
    ankle = (lanklem+lankle)/2;
    %scatter3(ankle(1),ankle(2),ankle(3),'cyan','filled','LineWidth',5);
    z = knee-ankle;
    z = z/norm(z);
    y = -cross((lankle-knee),(lanklem-knee));
    y = y/norm(y);
    x = -cross(y,z);
    T2 = [x,y,z,ankle;0 0 0 1];
    T = [T1;T2];
end
function T = footframe(pos)
    % Rfoot
    rankle = pos(:,7);
    ranklem = pos(:,17);
    ankle = (rankle+ranklem)/2;
    rtoe = pos(:,9);
    rheel = pos(:,8);
    y = rtoe-rheel;
    y = y/norm(y);
    x = cross((rtoe-rheel),(ankle-rheel));
    x = x/norm(x);
    z = cross(x,y);
    T1 = [x,y,z,rheel;0,0,0,1];
    % Lfoot
    lankle = pos(:,13);
    lanklem = pos(:,19);
    ankle = (lanklem+lankle)/2;
    ltoe = pos(:,15);
    lheel = pos(:,14);
    y = ltoe-lheel;
    y = y/norm(y);
    x = -cross((ltoe-lheel),(ankle-lheel));
    x = x/norm(x);
    z = -cross(x,y);
    T2 = [x,y,z,lheel;0,0,0,1];
    T =[T1;T2];
end