function init_BodyTree(model)
    global uLink
    if model == 'HH'
        %        Body
        %     /        \
        %    RThigh     0
        %     |     \
        %  RShank     LThigh
        %  |    \         |  \
        %  Rfoot Lshank   0   0
        %  /  \   / \
        %  0   0  0  0
        uLink(1).name = 'Pelvis';
        uLink(1).cpoint = [1,2,3];
        uLink(1).sister = 0; % sister表示同级
        uLink(1).child = 2; % child 表示子级
        uLink(2).name = 'RThigh';
        uLink(2).cpoint = [1,4,5];
        uLink(2).sister = 5;
        uLink(2).child = 3;
        uLink(3).name = 'RShank';
        uLink(3).cpoint = [5,6,7];
        uLink(3).sister = 6;
        uLink(3).child = 4;
        uLink(4).name =  'RFoot';
        uLink(4).cpoint = [7,8,9];
        uLink(4).sister = 0;
        uLink(4).child = 0;
        uLink(5).name = 'LThigh';
        uLink(5).cpoint = [2,10,11];
        uLink(5).sister = 0;
        uLink(5).child = 0;
        uLink(6).name = 'LShank';
        uLink(6).cpoint = [11,12,13];
        uLink(6).sister = 0;
        uLink(6).child = 7;
        uLink(7).name = 'LFoot';
        uLink(7).cpoint = [13,14,15];
        uLink(7).sister = 0;
        uLink(7).child = 0;
    end
end