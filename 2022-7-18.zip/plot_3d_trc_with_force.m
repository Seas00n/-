function plot_3d_trc_with_force(trc_file,force_file)
    trc = trc_file.Position;
    forces = force_file.ForceData;
    plates = force_file.Plates;
    n = size(trc,1);
    figure('Name','绘制3D轨迹和力');
    for i=1:15:n-1
        if i>n
            break;
        end
        plot3([0,0.5],[0,0],[0,0],'-r',...
              [0,0],[0,0.3],[0,0],'-g',...
              [0,0],[0,0],[0,0.6],'-b'); 
        hold on
        axis([0,1,0,3,-0.6,2]);
        plot_Body(trc_file,i);
        if sum(plates(:,i)~=0)==1
            % 单足
            idx = plates(:,i)~=0;
            cop1 = forces(i,4:6,idx);
            force1 = forces(i,1:3,idx);
            if force1(3)>0
                line([cop1(1),cop1(1)+force1(1)],...
                    [cop1(2),cop1(2)+force1(2)],...
                    [cop1(3),cop1(3)+force1(3)],'linewidth',2,'Color','blue');
                mag = norm(force1)*100;
                scatter3(cop1(1),cop1(2),cop1(3),mag,"blue",'filled');
            end
        else
            % 双足
            cop1 = forces(i,4:6,1);
            force1 = forces(i,1:3,1);
            if force1(3)>0
                line([cop1(1),cop1(1)+force1(1)],...
                    [cop1(2),cop1(2)+force1(2)],...
                    [cop1(3),cop1(3)+force1(3)],'linewidth',2,'Color','red');
                mag = norm(force1)*100;
                scatter3(cop1(1),cop1(2),cop1(3),mag,'red','filled');
            end
            cop2 = forces(i,4:6,2);
            force2 = forces(i,1:3,2);
            if(force2(3)>0)
                line([cop2(1),cop2(1)+force2(1)],...
                     [cop2(2),cop2(2)+force2(2)],...
                     [cop2(3),cop2(3)+force2(3)],'linewidth',2,'Color','red');
                mag = norm(force2)*100;
                scatter3(cop2(1),cop2(2),cop2(3),mag,'red','filled');
            end
        end
        axis equal
        hold off
        drawnow 
        pause(1/500);
    end
end
