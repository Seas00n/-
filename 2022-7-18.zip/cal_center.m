function centers = cal_center(trc,name,idx)
    global uLink
    narg = nargin;
    if narg==2
        mean_pos = mean(trc.Position,1);
        mean_pos = reshape(mean_pos,[3,trc.NumberMarkers]);
    else
        mean_pos = trc.Position(idx,:,:);
        mean_pos = reshape(mean_pos,[3,trc.NumberMarkers]);
    end
    centers = zeros(3,1);
    for i=1:size(uLink,2)
        if strcmp(uLink(i).name,name)
            idx = i;
            vertex = mean_pos(:,uLink(idx).cpoint);
            centers = mean(vertex,2);
            break;
        end
    end
end