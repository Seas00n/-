function plot_before_transformation(trc)
    scatter3(0,0,0,'linewidth',2);
    hold on
    line([0.5,0],[0,0],[0,0],'linewidth',2);
    line([0,0],[0.5,0],[0,0],'linewidth',2);
    line([0,0],[0,0],[0.5,0],'linewidth',2);
    plot_Body(trc,1);
    xlim([0,0.6]);
    ylim([0,0.6]);
    zlim([0,1]);
    xlabel('X/m');
    ylabel('Y/m');
    zlabel('Z/m');
    axis equal
end