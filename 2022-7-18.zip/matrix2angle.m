function q = matrix2angle(T)
    % 先绕固定轴x旋转row
    % 再绕固定轴y旋转pitch
    % 最后绕固定轴z旋转yaw
    R = T(1:3,1:3);
    pitch = asin(-R(3,1));
    rowcos = R(3,3)/cos(pitch);
    rowsin = R(3,2)/cos(pitch);
    % rowcos>pi/2-> cos(row)<0-> 2,3
    % rowsin> 0-> sin(row)>0-> 1,2
    % row->2----> 0->pi/2
    if(rowcos>pi/2 && rowsin>0) row = pi-rowsin;end
    % row->3----> -pi/2->pi/2
    if(rowcos>pi/2 && rowsin<0) row = -pi-rowsin;end
    if(rowcos<=pi/2) row = rowsin;end
    yawcos = R(1,1)/cos(pitch);
    yawsin = R(2,1)/cos(pitch);
    if(yawcos>pi/2 && yawsin>0) yaw = pi-yawsin;end
    if(yawcos>pi/2 && yawsin<0) yaw = -pi-yawsin;end
    if(yawcos<=pi/2) yaw = yawsin;end
    q = [row;pitch;yaw];
end