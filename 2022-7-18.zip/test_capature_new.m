clear all;clc;close all;

height = 1.80;
mass = 80;
global uLink
init_BodyTree('HH');
% 加载静态数据
name = "./data/static1";
trc_file = strcat(name,'.trc');
static_trc = new_load_trc(trc_file,"static");
%测试发现左右绑定反了
temp = static_trc.Position(:,:,1);
static_trc.Position(:,:,1)=static_trc.Position(:,:,2);
static_trc.Position(:,:,2) = temp;
temp = static_trc.Position(:,:,4:9);
static_trc.Position(:,:,4:9)=static_trc.Position(:,:,10:15);
static_trc.Position(:,:,10:15) = temp;
temp = static_trc.Position(:,:,16:17);
static_trc.Position(:,:,16:17)=static_trc.Position(:,:,18:19);
static_trc.Position(:,:,18:19) = temp;
% 加载动补数据
name="./data/obstacle_201";
trc_file = strcat(name,'.trc');
trc = new_load_trc(trc_file);
%plot_3d_trajectory(trc,'obstacle');pause(2);
%hold on
% 静态数据标定动捕点
trc = static_calibration(trc,static_trc);
% 计算角度
Tthigh_mat = zeros(4,4,trc.NumberFrames);
Ttrc_thigh_mat = zeros(4,4,trc.NumberFrames);
Tcal_thigh_mat = zeros(3,3,trc.NumberFrames);
Tshank_mat = zeros(4,4,trc.NumberFrames);
Ttrc_shank_mat = zeros(4,4,trc.NumberFrames);
Tcal_shank_mat = zeros(3,3,trc.NumberFrames);
Tfoot_mat = zeros(4,4,trc.NumberFrames);
Ttrc_foot_mat = zeros(4,4,trc.NumberFrames);
Tcal_foot_mat = zeros(3,3,trc.NumberFrames);
% 需要调整解剖坐标系方向(右乘列变换)
Tn = [0,-1,0;...
      1,0,0;...
      0,0,1];
for i=1:trc.NumberFrames
    % 大腿
    T = cal_frame(trc,'Thigh',i,Tn);
    a = T(1:4,:);
    Tthigh_mat(:,:,i)=a;
    rthigh_center = cal_center(trc,'RThigh',i);
    Ttrc_thigh_mat(:,:,i) = [eye(3) rthigh_center;0,0,0,1];
    inv_trc = [eye(3),-rthigh_center;0,0,0,1];
    Tcal_thigh_mat(:,:,i) = inv_trc(1:3,1:3)*a(1:3,1:3);
    % 小腿
    T = cal_frame(trc,'Shank',i,Tn);
    a = T(1:4,:);
    Tshank_mat(:,:,i)=a;
    rshank_center = cal_center(trc,'RShank',i);
    Ttrc_shank_mat(:,:,i) = [eye(3) rshank_center;0,0,0,1];
    inv_trc = [eye(3),-rshank_center;0,0,0,1];
    Tcal_shank_mat(:,:,i) = inv_trc(1:3,1:3)*a(1:3,1:3);
    % 足
    T = cal_frame(trc,'Foot',i,Tn);
    a = T(1:4,:);
    Tfoot_mat(:,:,i)=a;
    rfoot_center = cal_center(trc,'RFoot',i);
    Ttrc_foot_mat(:,:,i) = [eye(3) rfoot_center;0,0,0,1];
    inv_trc = [eye(3),-rfoot_center;0,0,0,1];
    Tcal_foot_mat(:,:,i) = inv_trc(1:3,1:3)*a(1:3,1:3);
%     hold on
%     if mod(i,100)==0
%         plot_frame(Tthigh_mat(:,:,i),Ttrc_thigh_mat(:,:,i));
%         plot_frame(Tshank_mat(:,:,i),Ttrc_shank_mat(:,:,i));
%         plot_frame(Tfoot_mat(:,:,i),Ttrc_foot_mat(:,:,i));
%         plot_Body(trc,i);
%     end
%     drawnow limitrate
end

thigh_angle = zeros(3,trc.NumberFrames);
for i=1:trc.NumberFrames
    thigh_angle(:,i) = matrix2angle(Tcal_thigh_mat(:,:,i));
end
figure('Name','绘制大腿角度')
plot(1:trc.NumberFrames,thigh_angle(1,:),'r','linewidth',2);
hold on
plot(1:trc.NumberFrames,thigh_angle(2,:),'g','linewidth',2);
plot(1:trc.NumberFrames,thigh_angle(3,:),'b','linewidth',2);
legend('x-row','y-pitch','z-yaw')

shank_angle = zeros(3,trc.NumberFrames);
for i=1:trc.NumberFrames
    shank_angle(:,i) = matrix2angle(Tcal_shank_mat(:,:,i));
end
figure('Name','绘制小腿角度')
plot(1:trc.NumberFrames,shank_angle(1,:),'r','linewidth',2);
hold on
plot(1:trc.NumberFrames,shank_angle(2,:),'g','linewidth',2);
plot(1:trc.NumberFrames,shank_angle(3,:),'b','linewidth',2);
legend('x-row','y-pitch','z-yaw')

foot_angle = zeros(3,trc.NumberFrames);
for i=1:trc.NumberFrames
    foot_angle(:,i) = matrix2angle(Tcal_foot_mat(:,:,i));
end
figure('Name','绘制足部角度')
plot(1:trc.NumberFrames,foot_angle(1,:),'r','linewidth',2);
hold on
plot(1:trc.NumberFrames,foot_angle(2,:),'g','linewidth',2);
plot(1:trc.NumberFrames,foot_angle(3,:),'b','linewidth',2);
legend('x-row','y-pitch','z-yaw')

figure("Name",'绘制足端轨迹')
idx_toe = uLink(4).cpoint;
toe_p =trc.Position(:,:,idx_toe(3));
plot3(toe_p(:,1), ...
      toe_p(:,2), ...
      toe_p(:,3),'Linewidth',3);
xlabel('x')
ylabel('y')
zlabel('z')


