function force_file = new_load_force(file)
    % File
    % DataRate
    % NumberFrames
    % NumberPlates
    % PlatePosition
    % ForceData
    % Plates
    fid = fopen(file,'r');
    if fid==-1
        disp('forces file not found');
        return;
    end
    force_file.File = file;
    line1 = fgetl(fid);
    line2 = fgetl(fid);
    nplates = regexp(line2,'\d*','match');
    force_file.NumberPlates = str2double(nplates{1});
    line3 = fgetl(fid);
    f = regexp(line3,'\d*\.\d*','match');
    force_file.DataRate = str2double(f{1});
    line4 = fgetl(fid);
    fn = regexp(line4,'\d*','match');
    force_file.NumberFrames = str2double(fn{1});
    line5 = fgetl(fid);
    force_data = zeros(force_file.NumberFrames,7,2);
    plates_position = zeros(force_file.NumberFrames,3,force_file.NumberPlates);
    plates = zeros(2,force_file.NumberFrames);
    plates_queue = zeros(2,2);
    for i=1:force_file.NumberFrames
        line = fgetl(fid);
        data = sscanf(line,'%f');
        data_all = reshape(data(2:end),[7,force_file.NumberPlates]);
        counter = 0;
        plates_queue(1,:) = plates_queue(2,:);
        for k=1:force_file.NumberPlates
            abs_force = sum(abs(data_all(1:3,k)));
            % 如果abs_force>200，表明脚踩在力板上，将该块板推入plates_queue
            if(abs_force>200)
                counter=counter+1;
                plates_queue(2,counter) = k;
            elseif abs_force==0
                plates_position(i,:,k) = data_all(4:6,k);
            end
        end
        if counter==1
            % 踩在单力板上
            if plates_queue(1,1)==plates_queue(2,1)
                plates_queue(2,2)=0;
                force_data(i,:,1) = data_all(:,plates_queue(2,1));
            else
               plates_queue(2,2)=plates_queue(2,1);
               plates_queue(2,1)=0;
               force_data(i,:,2) = data_all(:,plates_queue(2,2));
            end
        elseif counter==2
            % 双足支撑
            if sum(plates_queue(1,:)==0)==1
                %上一步是单足
                last = plates_queue(1,:)~=0;
                if plates_queue(2,last)==plates_queue(1,last)
                    % 不需要调整顺序
                else
                    % plates_queue(2,~last)==plates_queue(1,last)
                    temp = plates_queue(2,last);
                    plates_queue(2,last) =plates_queue(2,~last);
                    plates_queue(2,~last) = temp;
                end
            else
                %上一步是双足，继承之前的顺序
                plates_queue(2,:) = plates_queue(1,:);
            end
            force_data(i,:,1) = data_all(:,plates_queue(2,1));
            force_data(i,:,2) = data_all(:,plates_queue(2,2));
        end
        plates(:,i) = plates_queue(2,:);
    end
    plates = [plates(2,:);plates(1,:)];
    temp = force_data(:,:,2);
    force_data(:,:,2)=force_data(:,:,1);
    force_data(:,:,1)=temp;
    force_file.ForceData = force_data/1000;
    force_file.Plates = plates;
    plates_position_new = zeros(force_file.NumberPlates,3);
    for i=1:force_file.NumberPlates
        idx = plates_position(:,1,i)~=0;
        p = plates_position(idx,:,i);
        plates_position_new(i,:) = mean(p,1)/1000;
    end
    force_file.PlatesPosition = plates_position_new;
end