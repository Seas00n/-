function plot_3d_trajectory(trc,type)
    narg = nargin;
    n = trc.NumberFrames;
    with_obstacle = 0;
    if narg==2
        if strcmp(type,'obstacle')
            with_obstacle = 1;
        end
    end
    figure('Name','绘制3D行走轨迹')
    for i=1:5:n-1
        if i>n
            break;
        end
        plot3([0,0.5],[0,0],[0,0],'-r',...
              [0,0],[0,0.3],[0,0],'-g',...
              [0,0],[0,0],[0,0.6],'-b');
        hold on
        if with_obstacle
            plot_obstacle(trc);
        end
        axis([0,1,0,3,-0.6,2]);
        plot_Body(trc,i);
        axis equal
        hold off
        drawnow limitrate
        pause(1/120);
    end
end