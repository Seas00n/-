function plot_stairs(force_file,w,l)
    s = stairs_env(force_file.Plates,force_file.PlatesPosition,w,l);
    for i=1:size(s,1)
        plot3([s(i,3),s(i,5)],[s(i,4),s(i,6)],[s(i,2),s(i,2)],'-b',...
             [s(i,5),s(i,7)],[s(i,6),s(i,8)],[s(i,2),s(i,2)],'-b',...
             [s(i,7),s(i,9)],[s(i,8),s(i,10)],[s(i,2),s(i,2)],'-b',...
             [s(i,3),s(i,9)],[s(i,4),s(i,10)],[s(i,2),s(i,2)],'-b');
    end
    axis([0,1,0,3,-0.6,2]);
    axis equal
end
function stair = stairs_env(plates,plates_position,w,l)
    plates_order=[0];
    number_frames = size(plates,2);
    for i=1:number_frames
        first = plates(1,i);
        second = plates(2,i);
        push_first = 1;
        push_second = 1;
        if first==0
            push_first=0;
        end
        if second==0
            push_second=0;
        end
        for j=1:size(plates_order,2)
            if plates_order(j)==first
                push_first=0;
            end
            if plates_order(j)==second
                push_second=0;
            end
        end
        if push_first==1
            plates_order = [plates_order,first];
        end
        if push_second==1
            plates_order = [plates_order,second];
        end
    end
    plates_order = plates_order(2:end);
    stair = zeros(length(plates_order),1+1+8);
    for i=1:size(stair,1)
        stair(i,1)=plates_order(i);
        stair(i,2)=plates_position(plates_order(i),3);
        stair(i,3)=plates_position(plates_order(i),1)-w/2;
        stair(i,4)=plates_position(plates_order(i),2)-l/2;
        stair(i,5)=plates_position(plates_order(i),1)+w/2;
        stair(i,6)=plates_position(plates_order(i),2)-l/2;
        stair(i,7)=plates_position(plates_order(i),1)+w/2;
        stair(i,8)=plates_position(plates_order(i),2)+l/2;
        stair(i,9)=plates_position(plates_order(i),1)-w/2;
        stair(i,10)=plates_position(plates_order(i),2)+l/2;
    end
end