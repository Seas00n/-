function plot_Body(trc,idx)
    plot_Body_iter(1,trc,idx);
end
function plot_Body_iter(j,trc,idx)
    global uLink
    if j~=0
        point = uLink(j).cpoint;
        for m = 1:size(point,2)-1
            for n=1:size(point,2)
                line([trc.Position(idx,1,point(m)),trc.Position(idx,1,point(n))],...
                [trc.Position(idx,2,point(m)),trc.Position(idx,2,point(n))],...
                [trc.Position(idx,3,point(m)),trc.Position(idx,3,point(n))],'linewidth',2);  
            end
        end
        plot_Body_iter(uLink(j).child,trc,idx);
        plot_Body_iter(uLink(j).sister,trc,idx);
    end
end