function [Fp_mat, Mp_mat]=neinvdyn3d(dt,com,position_distal,position_proximal,angle,force_distal,moment_distal,name)
    % 牛顿欧拉法
    global uLink
    for i=1:size(uLink,2)
        if strcmp(uLink(i).name,name)
            mass = uLink(i).M;
            I_mat = uLink(i).Imat;
        end
    end
    [dp_com,ddp_com] = num_diff(dt,com);
    % 此处求出的是欧拉角的角速度和角加速度
    % 需要转换到全局坐标系下
    [dangle,ddangle] = num_diff(dt,angle);
    [dangle,ddangle] = eular_to_global(angle,dangle,ddangle);
    n = size(com,2);
    g=9.81;
    Fp_mat = zeros(3,n);
    Mp_mat = zeros(3,n);
    force_distal = force_distal*1000;
    moment_distal = moment_distal*1000;
    close all;
    figure(1)
    subplot(3,1,1)
    plot(1:size(force_distal,2),force_distal);
    subplot(3,1,2)
    plot(1:size(force_distal,2),moment_distal);
    subplot(3,1,3)
    plot(1:size(force_distal,2),angle);
    for i=1:n
        % 前向
        % 质心速度和加速度
        vi = dp_com(:,i);
        ai = ddp_com(:,i);
        % 角速度和角加速度
        wi = dangle(:,i);
        wdi = ddangle(:,i);
        % 惯性力和惯性矩
        Fi = mass*ai;
        Ni = I_mat*wdi+cross(wi,I_mat*wi);
        % 反向
        fdi = force_distal(:,i);
        mdi = moment_distal(:,i);
        rd = position_distal(:,i)-com(:,i);
        rp = position_proximal(:,i)-com(:,i);
        fpi = Fi-fdi-mass*[0;0;-g];
        mpi = Ni-mdi-cross(rd,fdi)-cross(rp,fpi);
        Fp_mat(:,i) = fpi;
        Mp_mat(:,i) = mpi;
    end
    Fp_mat = Fp_mat/1000;
    Mp_mat = Mp_mat/1000;
end
function [dp,ddp]=num_diff(dt,position)
    dp = diff(position,1,2)/dt;
    dp = [dp,dp(:,end)];
    ddp = diff(position,2,2)/dt/dt;
    ddp = [ddp,ddp(:,end-1),ddp(:,end)];
end
function [dq,ddq]=eular_to_global(q,dq,ddq)
    for i=1:size(q,2)
        r = q(1,i);
        p = q(2,i);
        y = q(3,i);
        J = [sin(p)*sin(y) cos(y)  0;...
             sin(p)*cos(y) -sin(y) 0;...
             cos(p)        0       1];
        dq_ = J*dq(:,i);
        Jd = [cos(p)*sin(y)+sin(p)*cos(y) -sin(y)  0;...
              cos(p)*cos(y)-sin(p)*sin(y), -cos(y) 0;...
             -sin(p)                       0       0];
        ddq_ = Jd*dq_+J*ddq(:,i);
        dq(:,i) = dq_;
        ddq(:,i) = ddq_;
    end
end