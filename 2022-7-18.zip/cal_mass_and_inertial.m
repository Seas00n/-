function cal_mass_and_inertial(mass,height,gender)
    global uLink
    for i=1:length(uLink)
        eval([uLink(i).name,'=',num2str(i),';']);
    end
    switch(gender)
        case 'female'
        Lt = 0.3685/1.735*height;
        uLink(LThigh).Pcom = [0,0,Lt*0.6388]';
        uLink(LThigh).M = 0.1478*mass;
        uLink(LThigh).Imat = uLink(LThigh).M*...
                            [(0.162*Lt)^2 0   0;
                            0   (0.364*Lt)^2 0;
                            0    0     (0.369*Lt)^2];
        uLink(RThigh).Pcom = uLink(LThigh).Pcom;
        uLink(RThigh).M = uLink(LThigh).M;
        uLink(RThigh).Imat = uLink(LThigh).Imat;
        Ls = 0.4323/1.735*height;
        uLink(LShank).Pcom = [0,0,Ls*0.5648]';
        uLink(LShank).M = 0.0481*mass;
        uLink(LShank).Imat =uLink(LShank).M*... 
                           [(0.093*Ls)^2 0   0;
                            0   (0.267*Ls)^2 0;
                            0    0     (0.271*Ls)^2];
        uLink(RShank).Pcom = uLink(LShank).Pcom;
        uLink(RShank).M = uLink(LShank).M;
        uLink(RShank).Imat = uLink(LShank).Imat;
        Lf = 0.2283/1.735*height; 
        uLink(LFoot).Pcom = [0 -0.4014*Lf 0]';
        uLink(LFoot).M = 0.0129*mass;
        uLink(LFoot).Imat = uLink(LFoot).M*...
                           [(0.139*Lf)^2,0,0;
                           0,(0.279*Lf)^2,0;
                           0,0,(0.299*Lf)^2];
        uLink(RFoot).Pcom = uLink(LFoot).Pcom;
        uLink(RFoot).M = uLink(LFoot).M;
        uLink(RFoot).Imat = uLink(LFoot).Imat;
        case 'male'
    end
end