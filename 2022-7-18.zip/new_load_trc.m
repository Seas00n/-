function trc = new_load_trc(file,is_static)
    % File
    % Position
    % Time
    % DataRate
    % CameraRate
    % NumberFrames
    % NumberMarkers
    % MarkerNames
    narg = nargin;
    if narg==2
        if strcmp(is_static,'static')
        HH_Markers = 19;
        end
    else
        HH_Markers = 15;
    end
    fid = fopen(file,'r');
    if(fid==-1)
        disp('trc file not found');
        return;
    end
    trc.File=file;
    % 跳过前两行
    line1 = fgetl(fid);
    line2 = fgetl(fid);
    line3 = fgetl(fid);
    file_info = sscanf(line3,"%f");
    trc.DataRate = file_info(1);
    trc.CameraRate = file_info(2);
    trc.NumberFrames = file_info(3);
    trc.NumberMarkers = file_info(4);
    trc.NumberOddMarkers = 0;
    if trc.NumberMarkers>HH_Markers
        % 非标准HH模型
        trc.NumberOddMarkers = trc.NumberMarkers-HH_Markers;
        trc.NumberMarkers = HH_Markers;
    end
    line4 = fgetl(fid);
    for i=1:trc.NumberMarkers
        name = sscanf(line4,[repmat('%*s',1,i+1),' %s'],1);%*s指的是跳过多少个字段
        names(i,1) = cellstr(name);
    end
    trc.MarkerNames = names(1:trc.NumberMarkers);
    % 跳过两行
    line5 = fgetl(fid);
    line6 = fgetl(fid);
    pos = zeros(trc.NumberFrames,trc.NumberMarkers*3);
    time = zeros(trc.NumberFrames,1);
    lose_point = 0;
    if trc.NumberOddMarkers~=0
        pos_odd = zeros(trc.NumberFrames, trc.NumberOddMarkers*3);
        pos_odd_lose_point = 0;
    end
    
    %使用第一行设置读取格式
    for i=1:trc.NumberFrames
        line = fgetl(fid);
        data = split(line,sprintf('\t'));
        time(i,1) = sscanf(data{2},'%f');
        offset = 2;
        % 读取正常数据
        for j=1:trc.NumberMarkers*3
            if isempty(data{j+offset})
                lose_point = 1;
            else
                pos(i,j) = sscanf(data{j+offset},'%f'); 
            end
        end
        % 读取额外数据
        if trc.NumberOddMarkers~=0
            offset = 2+trc.NumberMarkers*3;
            for j=1:3:trc.NumberOddMarkers*3
                if isempty(data{j+offset})&&isempty(data{j+1+offset})&&isempty(data{j+2+offset})
                    %三列全部为空，出现未绑定点
                    continue
                else
                    num_lose = 0;
                    for k=0:2
                        if isempty(data{j+k+offset})
                            num_lose=num_lose+1;
                            break;
                        else
                            pos_odd(i,j+k) = sscanf(data{j+k+offset},"%f");
                        end
                    end
                    if num_lose>0
                        pos_odd_lose_point =1;
                        pos_odd(i,:) = zeros(1,trc.NumberOddMarkers*3);
                        break;
                    end
                end
            end
        end
    end
    if lose_point
        pos = fill_lose_point(pos);
    end
    trc.Position = reshape(pos/1000,size(pos,1),3,size(pos,2)/3);
    trc.Time = time;
    if trc.NumberOddMarkers~=0
        % 去除未绑定点
        col_empty = [];
        for i=1:size(pos_odd,2)
            if pos_odd(:,i) == zeros(size(pos_odd,1),1)
               col_empty = [col_empty,i];
            end
        end
        if isempty(col_empty)
        else
            pos_odd(:,col_empty)=[];
        end
        if pos_odd_lose_point
            pos_odd = fill_lose_point(pos);
        end
        trc.NumberOddMarkers = size(pos_odd,2);
        trc.OddPosition = reshape(pos_odd/1000,size(pos_odd,1),3,size(pos_odd,2)/3);
    end
end
function pos = fill_lose_point(pos)
    idx_lose = zeros(1,size(pos,1));
    for i=1:size(pos,1)
        if sum(pos(i,:))==0
            idx_lose(i) = 1;
        end
    end
    mid_interval = find(idx_lose==0);
    left = mid_interval(1);
    right = mid_interval(end);
    for i=left:right-1
        if idx_lose(i)==1
            j=i+1;
            while(idx_lose(j)==1)
                j=j+1;
            end
            for k=1:size(pos,2)
                last = pos(i-1,k);
                next = pos(j,k);
                idx = (i:j-1)';
                pos(i:j-1,k) = (next-last)/(j-i+1)*(idx-i+1)+last;
            end
            i = j;
        end
    end
    if left>1
        for k=1:size(pos,2)
            next = pos(left,k);
            next_2 = pos(left+1,k);
            idx = (1:left-1)';
            pos(1:left-1,k) = next+(next_2-next)*(idx-left);
        end
    end
    if right<size(pos,1)
        for k=1:size(pos,2)
            last = pos(right,k);
            last_2 = pos(right-1,k);
            idx = right+1:size(pos,1);
            pos(right+1:size(pos,1),k) = last+(last-last_2)*(idx-right);
        end
    end
end