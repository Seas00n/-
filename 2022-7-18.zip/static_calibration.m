function trc = static_calibration(trc,static_trc)
    add_pos = 1;
    for i=1:length(trc.MarkerNames)
        if strcmp(trc.MarkerNames(i),'R.Knee.Medial')
            add_pos=0;
            break;
        end
    end
    if add_pos
        % 计算虚拟点和测量点的线性关系
        mean_pos = mean(static_trc.Position,1);
        mean_pos = reshape(mean_pos,[3,static_trc.NumberMarkers]);
        % r knee medial
        v_rkm = rkneem_relative(mean_pos);
        v_lkm = lkneem_relative(mean_pos);
        v_ram = ranklem_relative(mean_pos);
        v_lam = lanklem_relative(mean_pos);
        trc.NumberMarkers = 19;
        trc.MarkerNames = static_trc.MarkerNames(1:19);
        trc.Position = cat(3,trc.Position,zeros(trc.NumberFrames,3,4));
        for i=1:trc.NumberFrames
            idx_pos = trc.Position(i,:,:);
            idx_pos = reshape(idx_pos,[3,trc.NumberMarkers]);
            p_rkneem = estimate_rkneem(idx_pos,v_rkm);
            p_lkneem = estimate_lkneem(idx_pos,v_lkm);
            p_ranklem = estimate_ranklem(idx_pos,v_ram);
            p_lanklem = estimate_lanklem(idx_pos,v_lam);
%             if mod(i,10)==0
%             scatter3(p_rkneem(1),p_rkneem(2),p_rkneem(3),'cyan','filled','LineWidth',5);
%             scatter3(p_ranklem(1),p_ranklem(2),p_ranklem(3),'magenta','filled','LineWidth',5);
%             end
            idx_pos(:,end-3:end) = [p_rkneem,p_ranklem,p_lkneem,p_lanklem];
            trc.Position(i,:,:) = reshape(idx_pos,[1,3,trc.NumberMarkers]);
        end
    end
end
function R = cal_R_rthigh(pos)
    rasis = pos(:,1);
    lasis = pos(:,2);
    vsacral = pos(:,3);
    % 计算髋关节位置
    center = (rasis+lasis)/2;
    x = rasis-lasis;
    x = x/sqrt(sum(x.*x));
    z = cross((rasis-vsacral),(lasis-vsacral));
    z = z/sqrt(sum(z.*z));
    y = cross(z,x);
    R = [x y z];
    T = [R center;0 0 0 1];
    d = norm(rasis-lasis);
    p = [0.3*d;-0.19*d;-0.36*d;1];
    rhip = T*p;
    rhip = rhip(1:3);
    rthigh = pos(:,4);
    rknee = pos(:,5);
    p_knee_thigh = (rknee-rthigh);
    p_knee_thigh = p_knee_thigh/norm(p_knee_thigh);
    p_hip_thigh = (rhip-rthigh);
    p_hip_thigh = p_hip_thigh/norm(p_hip_thigh);
    p_normal =  cross(p_hip_thigh,p_knee_thigh);
    R = [p_hip_thigh,p_knee_thigh,p_normal];
end
function v_rkm=rkneem_relative(pos)
    rthigh = pos(:,4);
    rkneem = pos(:,16);
    p_kneem_thigh = (rkneem-rthigh);
    R = cal_R_rthigh(pos);
    v_rkm = R\p_kneem_thigh;
end
function p_rkneem = estimate_rkneem(pos,v_rkm)
   r_thigh = pos(:,4);
   R = cal_R_rthigh(pos);
   p_kneem_thigh = R*v_rkm;
   p_rkneem = p_kneem_thigh+r_thigh;
end



function R = cal_R_lthigh(pos)
    rasis = pos(:,1);
    lasis = pos(:,2);
    vsacral = pos(:,3);
    % 计算髋关节位置
    center = (rasis+lasis)/2;
    x = rasis-lasis;
    x = x/sqrt(sum(x.*x));
    z = cross((rasis-vsacral),(lasis-vsacral));
    z = z/sqrt(sum(z.*z));
    y = cross(z,x);
    R = [x y z];
    T = [R center;0 0 0 1];
    d = norm(rasis-lasis);
    p = [-0.3*d;-0.19*d;-0.36*d;1];
    lhip = T*p;
    lhip = lhip(1:3);
    lthigh = pos(:,10);
    lknee = pos(:,11);
    p_knee_thigh = (lknee-lthigh);
    p_knee_thigh = p_knee_thigh/norm(p_knee_thigh);
    p_hip_thigh = (lhip-lthigh);
    p_hip_thigh = p_hip_thigh/norm(p_hip_thigh);
    p_normal =  cross(p_hip_thigh,p_knee_thigh);
    R = [p_hip_thigh,p_knee_thigh,p_normal];
end
function v_lkm=lkneem_relative(pos)
    lthigh = pos(:,10);
    lkneem = pos(:,18);
    p_kneem_thigh = (lkneem-lthigh);
    R = cal_R_lthigh(pos);
    v_lkm = R\p_kneem_thigh;
end
function p_lkneem = estimate_lkneem(pos,v_lkm)
   l_thigh = pos(:,10);
   R = cal_R_lthigh(pos);
   p_kneem_thigh = R*v_lkm;
   p_lkneem = p_kneem_thigh+l_thigh;
end


function R = cal_R_rankle(pos)
    rknee = pos(:,5);
    rshank = pos(:,6);
    rankle = pos(:,7);
    p_knee_shank = (rknee-rshank)/norm(rknee-rshank);
    p_ankle_shank = (rankle-rshank)/norm(rankle-rshank);
    p_normal = cross(p_knee_shank,p_ankle_shank);
    R = [p_knee_shank,p_ankle_shank,p_normal];
end
function v_ram=ranklem_relative(pos)
    rshank = pos(:,6);
    ranklem = pos(:,17);
    p_anklem_shank = (ranklem-rshank);
    R = cal_R_rankle(pos);
    v_ram = R\p_anklem_shank;
end
function p_ranklem = estimate_ranklem(pos,v_ram)
    rshank = pos(:,6);
    R = cal_R_rankle(pos);
    p_ranklem = R*v_ram+rshank;
end


function R = cal_R_lankle(pos)
    lknee = pos(:,11);
    lshank = pos(:,12);
    lankle = pos(:,13);
    p_knee_shank = (lknee-lshank)/norm(lknee-lshank);
    p_ankle_shank = (lankle-lshank)/norm(lankle-lshank);
    p_normal = cross(p_knee_shank,p_ankle_shank);
    R = [p_knee_shank,p_ankle_shank,p_normal];
end
function v_lam=lanklem_relative(pos)
    lshank = pos(:,12);
    lanklem = pos(:,19);
    p_anklem_shank = (lanklem-lshank);
    R = cal_R_lankle(pos);
    v_lam = R\p_anklem_shank;
end
function p_lanklem = estimate_lanklem(pos,v_lam)
    lshank = pos(:,12);
    R = cal_R_rankle(pos);
    p_lanklem = R*v_lam+lshank;
end
