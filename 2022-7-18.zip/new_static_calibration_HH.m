function new_static_calibration_HH(trc_file)
    % Position [NumberFrames*3*NumberMarkers]
    % Time
    % DataRate
    % CameraRate
    % NumberFrames
    % NumberMarkers
    % MarkerNames
    static_trc = new_load_trc(trc_file);
    figure('Name','绘制静态标定坐标系')
    plot_before_transformation(static_trc);
    % 骨盆重心
    pelvis_center = cal_center(static_trc,'Pelvis');
    % 骨盆解剖坐标系到世界坐标系变换矩阵
    pelvis_frame = cal_frame(static_trc,'Pelvis');
    % 骨盆跟踪坐标系到世界坐标系变换矩阵
    trc_pelvis_frame = [eye(3) pelvis_center; 0 0 0 1];
    % 骨盆解剖坐标系到跟踪坐标系的变换矩阵
    pel_Ta = inv(trc_pelvis_frame)*pelvis_frame;
    plot_frame(pelvis_frame,trc_pelvis_frame);
    % 大腿重心
    rthigh_center = cal_center(static_trc,'RThigh');
    lthigh_center = cal_center(static_trc,'LThigh');
    % 大腿解剖坐标系到世界坐标系变换矩阵
    thigh_frame = cal_frame(static_trc,'Thigh');
    rthigh_frame = thigh_frame(1:4,:);
    lthigh_frame = thigh_frame(5:8,:);
    % 大腿跟踪坐标系到世界坐标系变换矩阵
    trc_rthigh_frame = [eye(3) rthigh_center; 0 0 0 1];
    trc_lthigh_frame = [eye(3) lthigh_center; 0 0 0 1];
    % 大腿解剖坐标系到跟踪坐标系的变换矩阵
    rthigh_Ta = inv(trc_rthigh_frame)*rthigh_frame;
    lthigh_Ta = inv(trc_lthigh_frame)*lthigh_frame;
    plot_frame(rthigh_frame,trc_rthigh_frame);
    plot_frame(lthigh_frame,trc_lthigh_frame);
    % 小腿重心
    rshank_center = cal_center(static_trc,'RShank');
    lshank_center = cal_center(static_trc,'LShank');
    % 小腿解剖坐标系到世界坐标系的变换矩阵
    shank_frame = cal_frame(static_trc,'Shank');
    rshank_frame = shank_frame(1:4,:);
    lshank_frame = shank_frame(5:8,:);
    % 小腿跟踪坐标系到世界坐标系的变换矩阵
    trc_rshank_frame = [eye(3) rshank_center; 0 0 0 1];
    trc_lshank_frame = [eye(3) lshank_center; 0 0 0 1];
    % 小腿解剖坐标系到跟踪坐标系的变换矩阵
    rshank_Ta = inv(trc_rshank_frame)*rshank_frame;
    lshank_Ta = inv(trc_lshank_frame)*lshank_frame;
    plot_frame(rshank_frame,trc_rshank_frame);
    plot_frame(lshank_frame,trc_lshank_frame);
    % 足重心
    rfoot_center = cal_center(static_trc,'RFoot');
    lfoot_center = cal_center(static_trc,'LFoot');
    % 足解剖坐标系到世界坐标系的变换矩阵
    foot_frame = cal_frame(static_trc,'Foot');
    rfoot_frame = foot_frame(1:4,:);
    lfoot_frame = foot_frame(5:8,:);
    % 足跟踪坐标系到世界坐标系的变换矩阵
    trc_rfoot_frame = [eye(3) rfoot_center; 0 0 0 1];
    trc_lfoot_frame = [eye(3) lfoot_center; 0 0 0 1];
    % 足解剖坐标系到跟踪坐标系的变换矩阵
    rfoot_Ta = inv(trc_rfoot_frame)*rfoot_frame;
    lfoot_Ta = inv(trc_rfoot_frame)*lfoot_frame;
    plot_frame(rfoot_frame,trc_rfoot_frame);
    plot_frame(lfoot_frame,trc_lfoot_frame);
end

